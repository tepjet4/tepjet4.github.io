import logo from './logo.svg';
import * as React from 'react';
import './App.css';
import '@fontsource/roboto/300.css';
import '@fontsource/roboto/400.css';
import '@fontsource/roboto/500.css';
import '@fontsource/roboto/700.css';
import { ThemeProvider, createTheme, useTheme} from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';

import {Box, Button, Paper, IconButton, Container, Grid, Typography} from '@mui/material';

import MenuBar from './components/MenuBar';
import Footer from './components/Footer';
import Pricing from './components/Pricing';
import Carousel from './components/Carousel';
import About from './components/About';
import Task1 from './components/Task1';
import Task2 from './components/Task2';
import MoreTasks from './components/MoreTasks';
import Newsletter from './components/Newsletter';
import Gantt from './components/Gantt';



const ColorModeContext = React.createContext({ toggleColorMode: () => {} });

const themeOptions = {
  palette: {
    primary: {
      main: '#074C63',
    },
    secondary: {
      main: '#6B8571',
    },
    error: {
      main: '#d32fcb',
    },
    warning: {
      main: '#ffee58',
    },
    /*background: {
      default: '#121212',
      paper: '#1c1c1c',
    },*/
  },
};

//const theme = createTheme(themeOptions);

function App() {
  
  const theme = useTheme();
  const colorMode = React.useContext(ColorModeContext);
  return (
    <>
    <MenuBar toggleColorMode={colorMode.toggleColorMode}/>
    <Newsletter/>
    <Container maxWidth="lg">
      
    <About/>
    <Task2/>
    <Task1/>
    <MoreTasks/>

    <Carousel/>
    <Pricing/>
    <Gantt/>
    </Container>
    <Footer/>
    </>
  );
}

//export default App;

export default function ToggleColorMode() {
  const [mode, setMode] = React.useState('dark');
  const colorMode = React.useMemo(
    () => ({
      toggleColorMode: () => {
        setMode((prevMode) => (prevMode === 'light' ? 'dark' : 'light'));
      },
    }),
    [],
  );

  const theme = React.useMemo(
    () =>
      createTheme({
        palette: {
          ...themeOptions.palette,
          mode: mode,
        },
      }),
    [mode],
  );

  return (
    <ColorModeContext.Provider value={colorMode}>
      {/*console.log(theme)*/}
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <App />
      </ThemeProvider>
    </ColorModeContext.Provider>
  );
}