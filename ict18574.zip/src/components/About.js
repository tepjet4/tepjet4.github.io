
import * as React from 'react';
import qrcode from '../img/qrcode.png' 

import {Box, Button, ButtonGroup, Paper, IconButton, Container, Grid, Typography} from '@mui/material';

function About() {
    return (
        <Grid id='About' container spacing={2} marginY={2} alignItems='center'>
            <Grid item xs={12} lg={8}>
            <Typography variant='h4' gutterBottom>About Us</Typography>
            <Typography variant='body2' sx={{textAlign:'justify'}} mb={2}>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</Typography>
            <ButtonGroup  color='secondary' variant='contained' aria-label="outlined button group">
                <Button href='/18574 Develop ICT Solution Assessment 1.docx' download>Assessment One</Button>
                <Button href='/18574 Develop ICT Solution Assessment 2.docx' download>Assessment Two</Button>
                <Button href='/Task 2 Selected solutions 18574.pptx' download>Cybersecurity Presentation</Button>
                <Button href='/ict18574.zip' download>
                    Download Source Code
                </Button>
            </ButtonGroup>
            </Grid>
            <Grid item xs={12} lg={4} textAlign='center' sx={{
          display: { xs: 'none', md: 'block' } }}>
            <Typography variant='h4' color='secondary'>View on mobile</Typography>
            <img src={qrcode} alt="qrcode" />
            </Grid>
        </Grid>
    )
}

export default About;