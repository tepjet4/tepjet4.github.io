
import * as React from 'react';
import qrcode from '../img/gantt.png' 

import {Box, Button, Paper, IconButton, Container, Grid, Typography} from '@mui/material';

function Gantt() {
    return (
        <Grid id='Gantt' container spacing={2} marginY={3} alignItems='center'>
            <Grid item xs={12}>
            <Typography variant='h3' gutterBottom>Heaven System's Project Gantt Chart</Typography>
            <Typography variant='body2' sx={{textAlign:'justify'}} mb={2}>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</Typography>
            <img src={qrcode} alt="gantt chart" width="100%" />
            <Button fullWidth variant='contained' href='https://tepjet4.github.io/heavenby18574/' target='_blank'>
                Go to Project's Website
            </Button>
            </Grid>
        </Grid>
    )
}

export default Gantt;