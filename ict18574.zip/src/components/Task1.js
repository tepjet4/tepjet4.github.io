
import * as React from 'react';
import qrcode from '../img/qrcode.png' 
import MyCard from './elements/MyCard'
import puppies from '../img/puppies.jpeg'
import puppies2 from '../img/puppies2.jpeg'
import puppies3 from '../img/puppies3.webp'

import {useTheme} from '@mui/material/styles';

import {Box, Button, Paper, IconButton, Container, Grid, Typography} from '@mui/material';

function Task1() {
    const theme = useTheme();
    return (
        <Grid id='Task1' container spacing={2} marginY={2} alignItems='center' columns={11} justifyContent='center'>
            <Grid container item xs={11} md={5} lg={2} flexDirection='row-reverse' justifyContent='center' alignSelf='normal' border='1px solid' borderColor='primary.dark'>
                <Typography variant='h2' gutterBottom sx={{
          writingMode: { md: 'sideways-lr', xs: 'lr' } }} textAlign='center'>Password Protection</Typography>
            </Grid>
            <Grid item container xs={11} md={5} lg={3} justifyContent='center'>
                <MyCard title='Password composition' image={puppies} content='An 8-letter password containing one uppercase letter could be cracked in as little as 22 minutes. Ensuring that passwords are at least 16 characters in length, while maintaining the historical complexity recommendations, improves password strength.'/>
            </Grid>
            <Grid item container xs={11} md={5} lg={3} justifyContent='center'>
                <MyCard title='Easy to remember but hard to guess' image={puppies2} content='It is difficult for individuals to remember long complex passwords, which can trigger them to reuse passwords across multiple accounts. Passphrases (e.g., This is actually a Great Password!) are a better solution because they are often easier to remember. They can be song lyrics, catchphrases, or quotes from books or films that are meaningful to the user.'/>
            </Grid>
            <Grid item container xs={11} md={5} lg={3} justifyContent='center'>
                <MyCard title='Multi-factor authentication' image={puppies3} content='Passwords are more secure than no protection, but they should not be the sole method for authenticating an identity or verifying access authorizations. Combining a password with multi-factor authentication (MFA) adds an additional layer of security and protection.'/>
            </Grid>
        </Grid>
    )
}

export default Task1;