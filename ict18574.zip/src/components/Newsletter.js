import React from "react";
import { Box, Container, Grid, Typography, FormControl, InputAdornment, InputLabel, OutlinedInput, Button } from "@mui/material";

import {useTheme} from '@mui/material/styles';

function Newsletter() {
  const [name, setName] = React.useState('');
  const theme = useTheme();
  return (
    <Box id="Newsletter"
      sx={{
        width: "100%",
        height: "auto",
        backgroundColor: theme.palette.mode === 'dark' ? "primary.main":"primary.light",
        paddingTop: "1rem",
        paddingBottom: "1rem",
        mt: 0
      }}
    >
      <Container maxWidth="xl">
        <Grid container direction="column" alignItems="center">
          <Grid item xs={12}>
            <Typography variant="h2" textAlign='center'>
                {`ICT Solutions`}
            </Typography>
            
            <Typography textAlign='center'>
                {`By Jorge Trujillo 18574 in ${new Date().getFullYear()}`}
            </Typography>
            <FormControl sx={{ m: 1, width: '50ch' }} variant="filled">
              <OutlinedInput
                id="newssletterSubscribe"
                fullWidth
                sx={{padding: '4px 0px', backgroundColor: 'white'}}
                placeholder="Email"
                value={name}
                onChange={(event) => {
                  setName(event.target.value);
                }}
                type='text' inputProps={{sx: {padding: '0px 0px 0px 16.5px', color: 'black'}}}
                endAdornment={
                  <InputAdornment position="end">
                    <Button variant='contained' size="large" sx={{padding: '2px 10px'}} color="info"
                      href={"mailto:email@example.com?subject=Newsletter subscription&body=Hello, I'd like to subscribe to your newsletter, this is my address: "+name}
                    >
                        Subscribe
                    </Button>
                  </InputAdornment>
                }
              />
            </FormControl>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};

export default Newsletter;