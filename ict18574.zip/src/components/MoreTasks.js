import * as React from 'react';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
import Button from '@mui/material/Button';
import Paper from '@mui/material/Paper';

import filestructure from '../img/filestructure.png'
import DogBreederQualityAssuranceChecklist from './elements/DogBreederQualityAssuranceChecklist';

export default function MoreTasks() {
  return (
    <Grid>
      
      <Typography variant='h3' textAlign='center' m={3}>AI Against Cyber Threats</Typography>
      <Accordion id='Malware Detection'>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2a-content"
          id="panel2a-header"
        >
          <Typography variant='h5'>Malware Detection</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
          AI can be used to analyze large amounts of data and detect patterns that indicate the presence of malware. This can help security teams identify and respond to threats more quickly and efficiently.
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion id='Network Security'>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2a-content"
          id="panel2a-header"
        >
          <Typography variant='h5'>Network Security</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
        AI can be used to analyze network traffic to detect suspicious activity, such as unusual data transfers or unusual requests for access to sensitive data. This can help security teams detect and respond to potential threats more quickly and effectively.
        </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion id='Fraud Detection'>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2a-content"
          id="panel2a-header"
        >
          <Typography variant='h5'>Fraud Detection</Typography>
        </AccordionSummary>
        <AccordionDetails>
        <Typography>
        AI can be used to identify fraudulent activity, such as credit card fraud or identity theft. This can help organizations prevent financial losses and protect customer data.
        </Typography>
        </AccordionDetails>
      </Accordion>
      
    </Grid>
  );
}