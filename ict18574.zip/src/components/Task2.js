
import * as React from 'react';
import qrcode from '../img/qrcode.png' 
import MyCard from './elements/MyCard'
import puppies from '../img/puppies.jpeg'
import emily from '../img/emily.jpeg'
import johnandsarah from '../img/johnandsarah.jpg'
import OpenInNewIcon from '@mui/icons-material/OpenInNew';


import {useTheme} from '@mui/material/styles';

import {Box, Button, Paper, IconButton, Container, Grid, Typography} from '@mui/material';

function Task2() {
    const theme = useTheme();
    return (
        <Paper id='Survey' sx={{p: 3}}>
            <Grid container spacing={2} marginY={2} alignItems='center'>
                <Grid item xs={12} md={12} textAlign='center'>
                <Typography variant='h4' gutterBottom>Usability Survey</Typography>
                <Typography variant='body1' gutterBottom textAlign='justify'>Please take a few minutes to complete this usability survey to help us improve the user experience of our website. Your feedback is valuable to us and will help us understand what we are doing well and what we can improve upon. Thank you for your participation!</Typography>
                <Grid container textAlign='center' alignContent='space-around' spacing={2} mt={1}>
                    <Grid item xs={12} md={6} textAlign='center'><Button variant="contained" href='https://forms.gle/LuMN4hJiTGDG9N9C6' target='_blank' endIcon={<OpenInNewIcon/>}>Go to Survey</Button></Grid>
                    <Grid item xs={12} md={6} textAlign='center'><Button variant="contained" href='https://docs.google.com/spreadsheets/d/1pC3HCFV_OucjQUAmalXtgwv2jZyqIXubhfLkwQ70hdc/edit?usp=sharing' target='_blank' endIcon={<OpenInNewIcon/>}>Check Results</Button></Grid>
                </Grid>
                </Grid>

            </Grid>
            </Paper>
    )
}

export default Task2;