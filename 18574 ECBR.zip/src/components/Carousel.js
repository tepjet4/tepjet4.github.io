
import * as React from 'react';
import { Carousel } from 'react-responsive-carousel';
import "react-responsive-carousel/lib/styles/carousel.min.css";

import slide from '../img/slide0.jpg'
import slide2 from '../img/slide1.jpg'
import slide3 from '../img/slide2.jpg'


import {Box, Button, Paper, IconButton, Container, Grid, Typography} from '@mui/material';

function CarouselSection() {
    return (
        <>
        <Typography variant="h3" textAlign='center' m={3}>
            {`AI in Cyber Security`}
        </Typography>
        <Carousel centerMode={true} centerSlidePercentage={75} infiniteLoop showThumbs={false}>
        <div>
            <img src={slide} />
            <p className="legend">A model set of opportunities and obstacles have emerged with the advent of the digital age. Cyber security testing has become increasingly important as organizations look to protect their networks, data, and systems from malicious attacks.</p>
        </div>
        <div>
            <img src={slide2} />
            <p className="legend">As it can gradually increase network security, artificial intelligence technology is more effective and sophisticated than its name might imply. Artificial intelligence uses machine learning and deep learning to understand more about the network behavior of an organization over time. They identify the patterns that are present on the network, and after doing so, the AI technology groups them together before moving on to determine whether any deviations from typical traffic or security incidents occurred. When it has finished processing the traffic, it reacts to them.</p>
        </div>
        <div>
            <img src={slide3} />
            <p className="legend">AI-based solutions have the potential to revolutionize the cybersecurity space. As organizations continue to invest in AI-based solutions, the technology will become more advanced and effective, allowing organizations to identify and mitigate current and future cybersecurity threats more effectively.</p>
        </div>
    </Carousel>
    </>
    )
}

export default CarouselSection;