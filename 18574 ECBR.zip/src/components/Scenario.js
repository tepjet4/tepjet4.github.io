import * as React from 'react';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
import Button from '@mui/material/Button';
import Paper from '@mui/material/Paper';
import System from '../img/system.png';
import filestructure from '../img/filestructure.png'

import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';


function createData(amount, hardware, software) {
  return { amount, hardware, software };
}

const rows = [
  createData('1', 'Server', 'Linux'),
  createData('2', 'EFTPOS', 'EFTPOS'),
  createData('10', 'PC Desktop', 'QuickBooks'),
  createData('2', 'Switches', '-'),
  createData('1', 'Router', '-'),
  createData('10', 'Printers', '-'),
];

export default function Scenario() {
  return (
    <Grid>
      
      <Typography id='Scenario' variant='h3' textAlign='center' m={3}>Business Scenario</Typography>
      <Typography textAlign='center' m={3}>D&K Books Pty Ltd is a bookstore owned by Mr. Dean Kerr. The business occupies two levels of an office building connected by escalators and lifts. D&K Books employs approximately six sales staff, one operation manager, two administrative officers, a bookkeeper and a marketing manager. They have an Ethernet network consisting of ten PCs (Intel I3 Desktop cloned), two switches, a router and three printers. They use the QuickBooks software to manage their entire business, including sales, inventory, ordering, accounts receivable, accounts payable, payroll and employee management. They also have two EFTPOS terminals one on each floor.  </Typography>
      <Accordion>
        <AccordionSummary sx={{backgroundColor: "primary.dark"}}
          expandIcon={<ExpandMoreIcon  sx={{color:'primary.contrastText'}}/>}
          aria-controls="panel2a-content"
          id="panel2a-header"
        >
          <Typography variant='h5' color='primary.contrastText'>Data Communication Diagram in the Book Shop</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <img src={System} alt="gantt chart" width="100%"/>
        </AccordionDetails>
      </Accordion>
      <Accordion id='Network Security'>
        <AccordionSummary sx={{backgroundColor: "primary.dark"}}
          expandIcon={<ExpandMoreIcon  sx={{color:'primary.contrastText'}}/>}
          aria-controls="panel2a-content"
          id="panel2a-header"
        >
          <Typography variant='h5' color='primary.contrastText'>Hardware and Software</Typography>
        </AccordionSummary>
        <AccordionDetails>
        <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="Hardware and Software Setting">
        <TableHead>
          <TableRow>
            <TableCell align="center">Amount</TableCell>
            <TableCell align="center">Hardware</TableCell>
            <TableCell align="center">Software</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow
              key={row.name+row.hardware}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell  align="center" component="th" scope="row">
                {row.amount}
              </TableCell>
              <TableCell align="center">{row.hardware}</TableCell>
              <TableCell align="center">{row.software}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
        </AccordionDetails>
      </Accordion>
      <Accordion id='Fraud Detection'>
        <AccordionSummary sx={{backgroundColor: "primary.dark"}}
          expandIcon={<ExpandMoreIcon  sx={{color:'primary.contrastText'}}/>}
          aria-controls="panel2a-content"
          id="panel2a-header"
        >
          <Typography variant='h5' color='primary.contrastText'>Business Support Area</Typography>
        </AccordionSummary>
        <AccordionDetails>
        <Typography>
        •	QuickBooks Software preinstall
        <br/>•	EFTPOS Machine for small business
        <br/>•	Website with online database
        <br/>•	Computer Server with Linux
        </Typography>
        </AccordionDetails>
      </Accordion>
      
    </Grid>
  );
}