import React from "react";
import { Box, Container, Grid, Typography, FormControl, InputAdornment, InputLabel, OutlinedInput, Button } from "@mui/material";

import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';
import { useTheme } from '@mui/material/styles';


const Alert = React.forwardRef(function Alert(props, ref) {
  return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

function Newsletter() {
  const [name, setName] = React.useState('');
  const [open, setOpen] = React.useState(false);

  const handleClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }

    setOpen(false);
  };

  
  const [openErr, setOpenErr] = React.useState(false);
        
  const handleCloseErr = (event, reason) => {
      if (reason === 'clickaway') {
      return;
      }

      setOpenErr(false);
  }; 

  const theme = useTheme();
  const scriptURL = 'https://script.google.com/macros/s/AKfycbwKUQWK9PJ7rTn1Y7_HadqAhihzqjNz04vNgC5OCKYeLgzj012JEMOvlVJ02BUx7v-PyA/exec'
  const form = document.forms['submit-to-google-sheet']
  return (
    <Box id="Newsletter"
      sx={{
        width: "100%",
        height: "auto",
        backgroundColor: theme.palette.mode === 'dark' ? "primary.main" : "primary.light",
        paddingTop: "3rem",
        paddingBottom: "3rem",
        mt: 0
      }}
    >
      <Container maxWidth="xl">
        <Grid container direction="column" alignItems="center">
          <Grid item xs={12}>
            <Typography variant="h3" textAlign='center'>
              {`ECBR`}
            </Typography>
            <Typography textAlign='center'>
              {`Evaluate and Communicate Business Requirements`}
            </Typography>
            <Typography textAlign='center'>
              {`By Jorge Trujillo 18574 in ${new Date().getFullYear()}`}
            </Typography>
            <form name="submit-to-google-sheet">
              <FormControl sx={{ m: 1, width: '50ch' }} variant="filled">
                <OutlinedInput
                  id="newssletterSubscribe"
                  fullWidth
                  sx={{ padding: '4px 0px', backgroundColor: 'white' }}
                  placeholder="Email"
                  value={name}
                  onChange={(event) => {
                    setName(event.target.value);
                  }}
                  type='email' name='email' inputProps={{ sx: { padding: '0px 0px 0px 16.5px', color: 'black' } }}
                  endAdornment={
                    <InputAdornment position="end">
                      <Button variant='contained' size="large" sx={{ padding: '2px 10px' }} color="info"
                        onClick={(e) => {
                          e.preventDefault(); fetch(scriptURL, { method: 'POST', body: new FormData(form) })
                            .then(response => { setOpen(true); setName('') })
                            .catch(error => { console.error('Error!', error.message); setOpenErr(true) })
                        }}
                      >
                        Subscribe
                      </Button>
                      <Snackbar open={open} autoHideDuration={6000} onClose={handleClose} anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}>
                        <Alert onClose={handleClose} severity="success" sx={{ width: '100%' }}>
                          Subscribed successfully!
                        </Alert>
                      </Snackbar>
                      <Snackbar open={openErr} autoHideDuration={6000} onClose={handleCloseErr}>
                        <Alert onClose={handleCloseErr} severity="error" sx={{ width: '100%' }}>
                          Error subscribing, please try again.
                        </Alert>
                      </Snackbar>
                    </InputAdornment>
                  }
                />
              </FormControl>
            </form>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};

export default Newsletter;