
import * as React from 'react';
import qrcode from '../img/gantt.png' 

import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';

import {Box, Button, Paper, IconButton, Container, Grid, Typography} from '@mui/material';

function createData(
    capacity,
    speed,
    price,
  ) {
    return { capacity, speed, price};
  }

const rows = [
    createData('1TB', '200MBps/180MBps', 'A$112'),
    createData('2TB', '200MBps/180MBps', 'A$126'),
    createData('4TB', '200MBps/180MBps', 'A$164'),
    createData('8TB', '200MBps/180MBps', 'A$189'),
    createData('SSD 1TB', '7450MBps/6900MBps', 'A$175'),
    createData('SSD 2TB', '7450MBps/6900MBps', 'A$320'),
    createData('Cloud Server', 'Internet upload and download speed', '$0.023 per GB transferred'),
  ];

function Gantt() {
    return (
        <Grid id='Gantt' container spacing={2} marginY={3} alignItems='center'>
            <Grid item xs={12}>
            <Typography variant='h3' gutterBottom>Gantt Chart</Typography>
            <Typography variant='body2' sx={{textAlign:'justify'}} mb={2}>This project involves a project manager, two senior developers, one UX designer, one graphics designer, and one junior developer. The project aims to develop a mobile app for a fictional e-commerce company.</Typography>
            <img src={qrcode} alt="gantt chart" width="100%"/>
            {/*<TableContainer component={Paper}>
                <Table sx={{ minWidth: 650 }} aria-label="simple table">
                    <TableHead>
                    <TableRow>
                        <TableCell>Capacity</TableCell>
                        <TableCell align="right">Speed&nbsp;(Read/Write)</TableCell>
                        <TableCell align="right">Price</TableCell>
                    </TableRow>
                    </TableHead>
                    <TableBody>
                    {rows.map((row) => (
                        <TableRow
                        key={row.capacity}
                        sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                        >
                        <TableCell component="th" scope="row">
                            {row.capacity}
                        </TableCell>
                        <TableCell align="right">{row.speed}</TableCell>
                        <TableCell align="right">{row.price}</TableCell>
                        </TableRow>
                    ))}
                    </TableBody>
                </Table>
                    </TableContainer>*/}
            <Button fullWidth variant='contained' href='/Gantt Web/18574.html' target='_blank'>
                Gantt Project Details
            </Button>
            </Grid>
        </Grid>
    )
}

export default Gantt;