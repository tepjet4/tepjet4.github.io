import { 
    Checkbox, 
    FormControlLabel, 
    FormGroup, 
    Typography,
    Container,
  } from '@mui/material';
  
  export default function DogBreederQualityAssuranceChecklist() {
    return (
      <Container px={3}>
        <Typography variant="h6">Health and Welfare of the dogs:</Typography>
        <FormGroup>
          <FormControlLabel 
            control={<Checkbox />} 
            label="All dogs have access to clean water and food at all times." 
          />
          <FormControlLabel 
            control={<Checkbox />} 
            label="Dogs are housed in clean, safe, and comfortable environments." 
          />
          <FormControlLabel 
            control={<Checkbox />} 
            label="Regular veterinary check-ups and vaccinations are carried out." 
          />
          <FormControlLabel 
            control={<Checkbox />} 
            label="Dogs are not bred until they reach a suitable age." 
          />
          <FormControlLabel 
            control={<Checkbox />} 
            label="Dogs are not overbred and are given adequate rest periods." 
          />
          <FormControlLabel 
            control={<Checkbox />} 
            label="Dogs are not kept in overcrowded conditions." 
          />
          <FormControlLabel 
            control={<Checkbox />} 
            label="Dogs are not subject to any form of cruelty or mistreatment." 
          />
        </FormGroup>
  
        <Typography variant="h6">Breeding Practices:</Typography>
        <FormGroup>
          <FormControlLabel 
            control={<Checkbox />} 
            label="Dogs are only bred with the intention of improving the breed." 
          />
          <FormControlLabel 
            control={<Checkbox />} 
            label="Dogs are bred to the breed standard and with consideration of their temperament." 
          />
          <FormControlLabel 
            control={<Checkbox />} 
            label="Only healthy dogs with no known hereditary or genetic conditions are used for breeding." 
          />
          <FormControlLabel 
            control={<Checkbox />} 
            label="Breeding is not carried out too frequently, and females are given time to recover between litters." 
          />
          <FormControlLabel 
            control={<Checkbox />} 
            label="The breeder does not engage in inbreeding or line breeding practices." 
          />
        </FormGroup>
  
        <Typography variant="h6">Sales and Marketing:</Typography>
        <FormGroup>
          <FormControlLabel 
            control={<Checkbox />} 
            label="The breeder provides accurate and detailed information about the dogs to potential buyers, including information about their breed, temperament, and health." 
          />
          <FormControlLabel 
            control={<Checkbox />} 
            label="All dogs are sold with appropriate documentation, including vaccination records, pedigree papers, and health certificates." 
          />
          <FormControlLabel 
            control={<Checkbox />} 
            label="The breeder ensures that the buyer is prepared and able to take care of the dog properly." 
          />
          <FormControlLabel 
            control={<Checkbox />} 
            label="The breeder does not sell dogs to pet stores or other retailers." 
          />
        </FormGroup>
  
        <Typography variant="h6">Customer Service:</Typography>
        <FormGroup>
          <FormControlLabel 
            control={<Checkbox />} 
            label="The breeder is available to answer any questions and provide guidance to the buyer." 
          />
          <FormControlLabel 
            control={<Checkbox />} 
            label="The breeder provides after-sales support, including advice on training, health care, and nutrition." 
          />
          <FormControlLabel 
            control={<Checkbox />} 
            label="The breeder is responsive to any concerns or issues raised by the buyer."
            />
            <FormControlLabel 
              control={<Checkbox />} 
              label="The breeder is willing to take back the dog if the buyer is no longer able to care for it." 
            />
          </FormGroup>
        
          <Typography variant="h6">Record Keeping:</Typography>
          <FormGroup>
            <FormControlLabel 
              control={<Checkbox />} 
              label="The breeder maintains accurate records of all breeding activities, including breeding pairs, birth dates, and health information." 
            />
            <FormControlLabel 
              control={<Checkbox />} 
              label="The breeder maintains accurate records of all sales and transfers of dogs." 
            />
            <FormControlLabel 
              control={<Checkbox />} 
              label="The breeder keeps these records for at least five years." 
            />
          </FormGroup>
        </Container>
    );
  }