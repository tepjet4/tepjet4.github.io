
import * as React from 'react';
//import qrcode from '../img/qrcode.png' 
import MyCard from './elements/MyCard'
import pic from '../img/interview.png'
import pic2 from '../img/questionaire.webp'
import pic3 from '../img/deliverablespng.png'

import {useTheme} from '@mui/material/styles';

import {Box, Button, Paper, IconButton, Container, Grid, Typography} from '@mui/material';

function Task1() {
    const theme = useTheme();
    return (
        <Grid id='Task1' container spacing={2} marginY={2} alignItems='center' columns={11} justifyContent='center'>
            <Grid container item xs={11} md={5} lg={2} flexDirection='row-reverse' justifyContent='center' alignSelf='normal' border='1px solid' borderColor='primary.dark'>
                <Typography variant='h2' gutterBottom sx={{
          writingMode: { md: 'sideways-lr', xs: 'lr' } }} textAlign='center'>Techniques</Typography>
            </Grid>
            <Grid item container xs={11} md={5} lg={3} justifyContent='center'>
                <MyCard title='Interviews' image={pic} content='Interviews are a great way to start the requirements elicitation process. They are invaluable for gathering background information on business needs, customers’ and users’ problems, and the concerns of support staff and other relevant stakeholders. Interviews can also be used in follow-up to gather more detailed information.

Interviews should cover a diverse and representative cross-section of the system’s stakeholders. You will want to include the full range of customer and user profiles. This is necessary to gain a proper perspective on competing needs, so your system requirements aren’t slanted in favor of one group.'/>
            </Grid>
            <Grid item container xs={11} md={5} lg={3} justifyContent='center'>
                <MyCard title='Questionnaires or Surveys' image={pic2} content='Individual interviews present several challenges. They can be tricky to schedule and time-consuming for the interviewers. Plus, the requirements you gather may only scratch the surface; not every interviewer is skilled at asking follow-up questions in real time.

Questionnaires (or surveys) can provide an efficient alternative. They allow follow-up with multiple stakeholders at the same time.

A well-thought-out questionnaire—one that asks probing questions—is a good tool for getting at those underlying requirements of which stakeholders may not be fully conscious, but which are essential to a successful design.
'/>
            </Grid>
            <Grid item container xs={11} md={5} lg={3} justifyContent='center'>
                <MyCard title='User Observation' image={pic3} content={`Technique #3: User Observation

One of the best ways to understand what users truly need is to observe them performing their daily tasks.

User observation can be either passive or active. Active observation—asking questions of users while observing them—is the best approach for gaining an understanding of an existing process. Passive observation is more effective when gathering user feedback on a design prototype (see technique #11).

When observing users, record the actions and activities that take place. What already works well? What causes users difficulty? Note the obstacles users must routinely overcome.
`}/>
            </Grid>
        </Grid>
    )
}

export default Task1;