
import * as React from 'react';
import qrcode from '../img/qrcode.png' 

import {Box, Button, ButtonGroup, Paper, IconButton, Container, Grid, Typography} from '@mui/material';

function About() {
    return (
        <Grid id='About' container spacing={2} marginY={2} alignItems='center'>
            <Grid item xs={12} lg={8}>
            <Typography variant='h4' gutterBottom>Evaluate and Communicate Business Requirements</Typography>
            <Typography variant='body1' sx={{textAlign:'justify'}} mb={2} mr={3}>
            While it would be convenient if gathering requirements simply involved asking stakeholders and customers what they want from a system, it's rarely that simple.

Stakeholders often lack awareness of the full range of options available for developing a product, as they're entrenched in the current status quo. Users find it hard to break away from their current methods and imagine significantly different possibilities.
<br/>There's no one-size-fits-all approach. No single technique ensures a complete set of requirements that can stand up to validation.
<br/>
That's why a multifaceted approach to requirements gathering is recommended. Best practices in requirements engineering suggest using a variety of methods tailored to different phases of the process.</Typography>
            <ButtonGroup  color='secondary' variant='contained' aria-label="outlined button group">
                <Button href='/18574 Evaluate and Communicate Business Requirements.docx' download>Assessment One</Button>
                <Button href='https://docs.google.com/spreadsheets/d/1uGUl8t-9ZpIMKdeh_VGPLxTG_6Ni4g12aFkbx4kDGMo/edit#gid=597825602' download>Google Sheets DB</Button>
                <Button href='/18574 ECBR.zip' download>
                    Download Source Code
                </Button>
            </ButtonGroup>
            </Grid>
            <Grid item xs={12} lg={4} textAlign='center' sx={{
          display: { xs: 'none', md: 'block'} }}>
            <img width='100%' style={{paddingTop:'10px', maxWidth:'500px'}} src={qrcode} alt="qrcode" />
            <Typography mb={2} variant='h6' color='secondary'>SCAN TO VIEW ON MOBILE</Typography>
            </Grid>
        </Grid>
    )
}

export default About;