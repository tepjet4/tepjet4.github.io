import React from "react";
import { Box, Container, Grid, Typography, FormControl, InputAdornment, InputLabel, OutlinedInput, Button, TextField, Select, MenuItem } from "@mui/material";

import { useTheme } from '@mui/material/styles';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import { Email, Phone } from "@mui/icons-material";

import Snackbar from '@mui/material/Snackbar';
import MuiAlert from '@mui/material/Alert';

const states = [

    {
        value: 'new-south-wales',
        label: 'New South Wales',
    },
    {
        value: 'victoria',
        label: 'Victoria',
    },
    {
        value: 'queensland',
        label: 'Queensland',
    },
    {
        value: 'south-australia',
        label: 'South Australia',
    },
    {
        value: 'western-australia',
        label: 'Western Australia',
    },
    {
        value: 'tasmania',
        label: 'Tasmania',
    },
    {
        value: 'northern-territory',
        label: 'Northern Territory',
    },
    {
        value: 'australian-capital-territory',
        label: 'Australian Capital Territory',
    },
];

const Alert = React.forwardRef(function Alert(props, ref) {
    return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

function ContactForm() {
    const styles = {

    }
    const [open, setOpen] = React.useState(false);
        
    const handleClose = (event, reason) => {
        if (reason === 'clickaway') {
        return;
        }

        setOpen(false);
    };

    
    const [openErr, setOpenErr] = React.useState(false);
        
    const handleCloseErr = (event, reason) => {
        if (reason === 'clickaway') {
        return;
        }

        setOpenErr(false);
    }; 
    const [name, setName] = React.useState('');
    const [email, setEmail] = React.useState('');
    const [comment, setComment] = React.useState('');
    const [state, setState] = React.useState('');
    const theme = useTheme();
    const scriptURL = 'https://script.google.com/macros/s/AKfycbx8LRQTws8lxmvPscM2Eadan_s_xPQJ8PIvE_-j1BlcXd3aSuZTFOLdcxzXJmtNXeNgsA/exec'
    const form = document.forms['contactus-to-google-sheet']

    const resetContact = () => {
        setName('')
        setEmail('')
        setComment('')
        setState('')
    };
    return (
        <Box id="ContactForm"
            sx={{
                width: "100%",
                height: "auto",
                backgroundColor: theme.palette.mode === 'dark' ? "primary.main" : "primary.light",
                paddingTop: "3rem",
                paddingBottom: "3rem",
                mt: 2
            }}
        >
            <Container maxWidth="xl">

                <Typography variant="h3" textAlign='center' color='text.primary'>
                    Contact Us
                </Typography>
                <Grid container direction='row'>
                    <Grid container wrap="nowrap" item direction="column" alignItems="center" xs={12} md={4}>
                        <Grid item xs={12}>
                            <Typography variant="h4" color='text.secondary'>Send us a message</Typography>
                        </Grid>

                        <Grid item xs={12}
                        >
                            <LocationOnIcon sx={{ mr: 1, color: 'text.primary', verticalAlign: 'sub' }} />
                            <Typography
                                variant="h7"
                                noWrap
                                component="a"
                                href="/"
                                sx={{
                                    mr: 2,
                                    fontFamily: 'monospace',
                                    fontWeight: 700,
                                    letterSpacing: '.1rem',
                                    color: 'text.secondary',
                                    textDecoration: 'none',
                                }}
                            >
                                Sydney, NSW 2000
                            </Typography>
                        </Grid>
                        <Grid item xs={12}
                        >
                            <Phone sx={{ mr: 1, color: 'text.primary', verticalAlign: 'sub' }} />
                            <Typography
                                variant="h7"
                                noWrap
                                component="a"
                                href="/"
                                sx={{
                                    mr: 2,
                                    fontFamily: 'monospace',
                                    fontWeight: 700,
                                    letterSpacing: '.1rem',
                                    color: 'text.secondary',
                                    textDecoration: 'none',
                                }}
                            >
                                0497123123
                            </Typography>
                        </Grid>
                        <Grid item xs={12}
                        >
                            <Email sx={{ mr: 1, color: 'text.primary', verticalAlign: 'sub' }} />
                            <Typography
                                variant="h7"
                                noWrap
                                component="a"
                                href="/"
                                sx={{
                                    mr: 2,
                                    fontFamily: 'monospace',
                                    fontWeight: 700,
                                    letterSpacing: '.1rem',
                                    color: 'text.secondary',
                                    textDecoration: 'none',
                                }}
                            >
                                18574@wic.edu.au
                            </Typography>
                        </Grid>
                    </Grid>
                    <Grid container item direction="row" alignItems="center" xs={12} md={8}>

                        <form name="contactus-to-google-sheet" style={{ width: "100%" }}>
                            <Grid container columns={13} spacing={0} direction="row" justifyContent="space-between" alignItems="flex-end" columnGap={1}>
                                <Grid item container xs={12} sm={6}>
                                    <FormControl fullWidth>
                                        <TextField
                                            id="name"
                                            label="Name"
                                            name="name"
                                            variant="outlined"
                                            value={name}
                                            onChange={(e) => setName(e.target.value)}
                                            fullWidth
                                            margin="normal"
                                            required
                                        />
                                    </FormControl>
                                </Grid>
                                <Grid item xs={13} sm={6}>
                                    <FormControl fullWidth>
                                        <TextField id="email" name="email" label="Email" variant="outlined" value={email} onChange={(e) => setEmail(e.target.value)}
                                            fullWidth margin="normal" required />
                                    </FormControl>
                                </Grid>
                                <Grid item xs={13}>
                                    <FormControl fullWidth>
                                        <TextField
                                            id="comment"
                                            name="comment"
                                            label="Comment"
                                            variant="outlined"
                                            value={comment}
                                            onChange={(e) => setComment(e.target.value)}
                                            fullWidth
                                            margin="normal"
                                            multiline
                                            rows={4}
                                            required
                                        />
                                    </FormControl>
                                </Grid>
                                <Grid item xs={13} sm={6}>
                                    <FormControl fullWidth margin="normal" required>
                                        <InputLabel id="state-label">State</InputLabel>
                                        <Select
                                            labelId="state-label"
                                            id="state"
                                            name="state"
                                            value={state}
                                            fullWidth
                                            onChange={(e) => setState(e.target.value)}
                                            label="State"
                                        >
                                            {states.map((option) => (
                                                <MenuItem key={option.value} value={option.value}>
                                                    {option.label}
                                                </MenuItem>
                                            ))}
                                        </Select>
                                    </FormControl>
                                </Grid>
                                <Grid item xs={13} sm={6} mb={1}>
                                    <Button type="submit" variant="contained" color="secondary" fullWidth
                                        onClick={(e) => {
                                            e.preventDefault(); fetch(scriptURL, { method: 'POST', body: new FormData(form) })
                                                .then(response => {setOpen(true); resetContact()})
                                                .catch(error => {console.error('Error!', error.message); setOpenErr(true)})
                                        }}
                                    >
                                        Submit
                                    </Button>
                                    <Snackbar open={open} autoHideDuration={6000} onClose={handleClose} anchorOrigin={{vertical: 'bottom', horizontal: 'center'}}>
                                        <Alert onClose={handleClose} severity="success" sx={{ width: '100%' }}>
                                            Message sent successfully!
                                        </Alert>
                                    </Snackbar>
                                    <Snackbar open={openErr} autoHideDuration={6000} onClose={handleCloseErr}>
                                        <Alert onClose={handleCloseErr} severity="error" sx={{ width: '100%' }}>
                                            Error sending message, please try again.
                                        </Alert>
                                    </Snackbar>
                                </Grid>
                            </Grid>
                        </form>
                    </Grid>
                </Grid>
            </Container>
        </Box>
    );
};

export default ContactForm;