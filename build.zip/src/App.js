import logo from './logo.svg';
import * as React from 'react';
import './App.css';
import '@fontsource/roboto/300.css';
import '@fontsource/roboto/400.css';
import '@fontsource/roboto/500.css';
import '@fontsource/roboto/700.css';
import { ThemeProvider, createTheme, useTheme} from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';

import {Box, Button, Paper, IconButton, Container, Grid, Typography} from '@mui/material';

import MenuBar from './components/MenuBar';
import Footer from './components/Footer';
import Pricing from './components/Pricing';
import About from './components/About';
import Task1 from './components/Task1';
import Task2 from './components/Task2';
import MoreTasks from './components/MoreTasks';



const ColorModeContext = React.createContext({ toggleColorMode: () => {} });

const themeOptions = {
  palette: {
    primary: {
      main: '#ffa500',
    },
    secondary: {
      main: '#ff8c00',
    },
    error: {
      main: '#d32fcb',
    },
    warning: {
      main: '#ffee58',
    },
    /*background: {
      default: '#121212',
      paper: '#1c1c1c',
    },*/
  },
};

//const theme = createTheme(themeOptions);

function App() {
  
  const theme = useTheme();
  const colorMode = React.useContext(ColorModeContext);
  return (
    
    <Container maxWidth="lg">
      <MenuBar toggleColorMode={colorMode.toggleColorMode}/>
      
    <About/>
    <Task1/>
    <Task2/>
    <MoreTasks/>


    <Pricing/>
    <Footer/>
    </Container>
  );
}

//export default App;

export default function ToggleColorMode() {
  const [mode, setMode] = React.useState('dark');
  const colorMode = React.useMemo(
    () => ({
      toggleColorMode: () => {
        setMode((prevMode) => (prevMode === 'light' ? 'dark' : 'light'));
      },
    }),
    [],
  );

  const theme = React.useMemo(
    () =>
      createTheme({
        palette: {
          ...themeOptions.palette,
          mode: mode,
        },
      }),
    [mode],
  );

  return (
    <ColorModeContext.Provider value={colorMode}>
      {console.log(theme)}
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <App />
      </ThemeProvider>
    </ColorModeContext.Provider>
  );
}