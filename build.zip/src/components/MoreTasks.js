import * as React from 'react';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
import Button from '@mui/material/Button';
import Paper from '@mui/material/Paper';

import filestructure from '../img/filestructure.png'
import DogBreederQualityAssuranceChecklist from './elements/DogBreederQualityAssuranceChecklist';

export default function MoreTasks() {
  return (
    <Grid>
      <Accordion id='MoreTasks' defaultExpanded>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          <Typography variant='h5'>Task 5</Typography>
        </AccordionSummary>
        <AccordionDetails>
            <Paper id='Task6' sx={{p: 3}}>
            <Grid container spacing={2} marginY={2} alignItems='center'>
                <Grid item xs={12} md={12} textAlign='center'>
                <Typography variant='h4' gutterBottom>Usability Survey</Typography>
                <Typography variant='body1' gutterBottom textAlign='justify'>Please take a few minutes to complete this usability survey to help us improve the user experience of our website. Your feedback is valuable to us and will help us understand what we are doing well and what we can improve upon. Thank you for your participation!</Typography>
                <Grid container textAlign='center' alignContent='space-around' spacing={2} mt={1}>
                    <Grid item xs={12} md={6} textAlign='center'><Button variant="contained" href='https://forms.gle/LuMN4hJiTGDG9N9C6' target='_blank' endIcon={<OpenInNewIcon/>}>Go to Survey</Button></Grid>
                    <Grid item xs={12} md={6} textAlign='center'><Button variant="contained" href='https://forms.gle/LuMN4hJiTGDG9N9C6' target='_blank' endIcon={<OpenInNewIcon/>}>Check Results</Button></Grid>
                </Grid>
                </Grid>

            </Grid>
            </Paper> 
        </AccordionDetails>
      </Accordion>
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2a-content"
          id="panel2a-header"
        >
          <Typography variant='h5'>Task 6</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
            malesuada lacus ex, sit amet blandit leo lobortis eget.
          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2a-content"
          id="panel2a-header"
        >
          <Typography variant='h5'>Task 7</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <DogBreederQualityAssuranceChecklist/>
        </AccordionDetails>
      </Accordion>
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2a-content"
          id="panel2a-header"
        >
          <Typography variant='h5'>Task 8</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <img style={{maxWidth:'100%'}} src={filestructure}/>
        </AccordionDetails>
      </Accordion>
      
    </Grid>
  );
}