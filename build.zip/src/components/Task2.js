
import * as React from 'react';
import qrcode from '../img/qrcode.png' 
import MyCard from './elements/MyCard'
import puppies from '../img/puppies.jpeg'
import emily from '../img/emily.jpeg'
import johnandsarah from '../img/johnandsarah.jpg'

import {Box, Button, Paper, IconButton, Container, Grid, Typography} from '@mui/material';

function Task2() {
    
    return (
        <Grid id='Task2' container spacing={2} marginY={2} alignItems='center' columns={11}>
            <Grid item xs={8} lg={3}>
            <Typography variant='h4' color="secondary" gutterBottom>Target Users</Typography>
            <Typography variant='body2' sx={{textAlign:'justify'}}>
                <p>The target users for a dog breeder are typically individuals or families who are looking to add a new pet to their household and are specifically interested in purebred dogs. These may include:</p>
                <ul>
                <li><b>Pet owners:</b> People who are looking for a companion animal to add to their family.</li>
                <li><b>Show dog enthusiasts:</b> Individuals who participate in dog shows and competitions and are looking for high-quality, purebred dogs to compete with.</li>
                <li><b>Breed enthusiasts:</b> People who are passionate about a particular breed of dog and are looking for a breeder who specializes in that breed.</li>
                <li><b>Service dog organizations:</b> Organizations that train and provide service dogs for people with disabilities or other special needs may be interested in working with a reputable breeder to obtain dogs with the specific traits and characteristics necessary for service work.</li>
                <li><b>Other breeders:</b> Other dog breeders may be interested in purchasing dogs from a reputable breeder to add to their own breeding programs.</li>
                </ul>
            </Typography>
            </Grid>
            <Grid item xs={8} lg={3}>
                <MyCard title='Persona 1: Emily the dog lover' image={emily} content="Demographic: Female, 27 years old, single
Occupation: Marketing manager
Interests: Emily loves dogs and spends most of her free time volunteering at a local animal shelter. She is looking for a dog breeder who is responsible and ethical, and who can help her find the perfect furry companion.
Goals and needs: Emily is looking for a specific breed of dog that is known for being good with children and has a friendly personality. She wants a breeder who can provide her with information about the dog's health history, temperament, and breeding history. She is also looking for a breeder who is committed to ethical breeding practices."/>
            </Grid>
            <Grid item xs={8} lg={3}>
                <MyCard title='Persona 2: John and Sarah, the new dog owners' image={johnandsarah} content='Demographic: Couple in their early 30s, married with one child
    Occupation: John is a software engineer and Sarah is a stay-at-home mom
    Interests: John and Sarah are looking to add a new furry member to their family. They enjoy hiking and outdoor activities, and want a dog that can keep up with their active lifestyle.
    Goals and needs: John and Sarah are looking for a breeder who can help them find a healthy and active puppy from a specific breed that is known for being energetic and good with children. They want to make sure that the puppy they choose is well-socialized and will fit well into their family dynamic.'/>
            </Grid>
            <Grid container item xs={8} lg={2}>
                <Typography variant='h1' gutterBottom sx={{
          writingMode: { md: 'sideways-rl', xs: 'lr' } }}>Task 2</Typography>
            </Grid>
        </Grid>
    )
}

export default Task2;