
import * as React from 'react';
import qrcode from '../img/qrcode.png' 
import MyCard from './elements/MyCard'
import puppies from '../img/puppies.jpeg'
import puppies2 from '../img/puppies2.jpeg'
import puppies3 from '../img/puppies3.webp'

import {Box, Button, Paper, IconButton, Container, Grid, Typography} from '@mui/material';

function Task1() {
    
    return (
        <Grid id='Task1' container spacing={2} marginY={2} alignItems='center' columns={11}>
            <Grid container item xs={8} lg={2} flexDirection='row-reverse'>
                <Typography variant='h1' gutterBottom sx={{
          writingMode: { md: 'sideways-lr', xs: 'lr' } }}>Task 1</Typography>
            </Grid>
            <Grid item xs={8} lg={3}>
                <MyCard title='Business Requirement' image={puppies} content='The German Shepherd breeder in Sydney requires a website to showcase their dogs, provide information on their breeding process, and allow interested buyers to make inquiries and purchases online.'/>
            </Grid>
            <Grid item xs={8} lg={3}>
                <MyCard title='Business Problem' image={puppies2} content='The German Shepherd breeder in Sydney is finding it difficult to reach potential buyers and showcase the quality of their dogs due to a lack of an online presence. They rely on word of mouth referrals and local advertising, which limits their reach and ability to connect with potential buyers.'/>
            </Grid>
            <Grid item xs={8} lg={3}>
                <MyCard title='Business Goal' image={puppies3} content='The goal of the German Shepherd breeder in Sydney is to establish an online presence that showcases the quality of their breeding and provides a platform for interested buyers to inquire and purchase dogs. By doing so, the breeder hopes to increase their reach and sales, as well as establish a reputation as a trusted and reputable breeder within the German Shepherd community in Sydney.'/>
            </Grid>
        </Grid>
    )
}

export default Task1;