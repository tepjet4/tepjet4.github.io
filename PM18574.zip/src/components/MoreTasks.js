import * as React from 'react';
import Accordion from '@mui/material/Accordion';
import AccordionSummary from '@mui/material/AccordionSummary';
import AccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import OpenInNewIcon from '@mui/icons-material/OpenInNew';
import Button from '@mui/material/Button';
import Paper from '@mui/material/Paper';

import filestructure from '../img/filestructure.png'
import DogBreederQualityAssuranceChecklist from './elements/DogBreederQualityAssuranceChecklist';

export default function MoreTasks() {
  return (
    <Grid>
      
      <Typography id='Criticality' variant='h3' textAlign='center' m={3}>Identifying Critical System</Typography>
      <Typography textAlign='center' m={3}>What factors would need to be considered in determining whether this new system will be critical to the business and what the impact might be if it fails? </Typography>
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2a-content"
          id="panel2a-header"
        >
          <Typography variant='h5'>Need to consider</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
          · Do the company's customers prefer or are increasingly moving towards online shopping?
          <br/>· Is the company looking to reach a larger customer base?
          <br/>· Have the costs and benefits of implementing and maintaining an e-commerce platform been analysed?
          <br/>· Can e-commerce enhance operational efficiency in areas such as order management, inventory control, and customer support?

          </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion id='Network Security'>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2a-content"
          id="panel2a-header"
        >
          <Typography variant='h5'>Good impact</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
          •	System data backup.
          <br/>•	Email to contact customer.
          <br/>•	The system could save labour cost.
          <br/>•	E-commerce can streamline various business processes, such as order management, inventory control, and customer support.
          <br/>•	In today's digital age, the presence of an e-commerce presence can positively impact a brand's perception. Consumers may view a business without an E-commerce as outdated or less trustworthy, affecting the overall brand reputation.
        </Typography>
        </AccordionDetails>
      </Accordion>
      <Accordion id='Fraud Detection'>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel2a-content"
          id="panel2a-header"
        >
          <Typography variant='h5'>Impact if failure</Typography>
        </AccordionSummary>
        <AccordionDetails>
        <Typography>
        •	If the e-commerce becomes a significant revenue channel, its failure can result in a decline in sales and revenue.
        <br/>•	Frustrated customers may turn to competitors if they cannot easily purchase products online.
        <br/>•	If the system is not successful the cost of the system development would be a loss.

        </Typography>
        </AccordionDetails>
      </Accordion>
      
    </Grid>
  );
}