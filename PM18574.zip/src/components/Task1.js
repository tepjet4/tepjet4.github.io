
import * as React from 'react';
//import qrcode from '../img/qrcode.png' 
import MyCard from './elements/MyCard'
import pic from '../img/projectscope.png'
import pic2 from '../img/risk.webp'
import pic3 from '../img/deliverablespng.png'

import {useTheme} from '@mui/material/styles';

import {Box, Button, Paper, IconButton, Container, Grid, Typography} from '@mui/material';

function Task1() {
    const theme = useTheme();
    return (
        <Grid id='Task1' container spacing={2} marginY={2} alignItems='center' columns={11} justifyContent='center'>
            <Grid container item xs={11} md={5} lg={2} flexDirection='row-reverse' justifyContent='center' alignSelf='normal' border='1px solid' borderColor='primary.dark'>
                <Typography variant='h2' gutterBottom sx={{
          writingMode: { md: 'sideways-lr', xs: 'lr' } }} textAlign='center'>E-commerce App</Typography>
            </Grid>
            <Grid item container xs={11} md={5} lg={3} justifyContent='center'>
                <MyCard title='Project Scope' image={pic} content='This project encompasses the entire development lifecycle of a mobile application, built using React Native technology. It includes essential components such as user registration, product catalog, shopping cart management, order processing, and an administrative panel for content management. The scope focuses on creating a mobile solution, excluding web-based interfaces and language localization beyond the default language.'/>
            </Grid>
            <Grid item container xs={11} md={5} lg={3} justifyContent='center'>
                <MyCard title='Key Features' image={pic2} content='Throughout this project, we will navigate potential risks, such as technical challenges, resource availability, scope creep, and third-party dependencies, while also leveraging opportunities to innovate and deliver a mobile app that will delight our client and their customers.

This project represents an exciting journey into the realm of mobile app development, where we will harness the expertise and creativity of our project team to craft a solution that will set new industry standards and provide a memorable shopping experience for users.'/>
            </Grid>
            <Grid item container xs={11} md={5} lg={3} justifyContent='center'>
                <MyCard title='Deliverables' image={pic3} content={`The project will yield a comprehensive project plan, detailing timelines, task assignments, and dependencies. It will encompass the development of the backend infrastructure, including server setup, database schema design, and the creation of essential API endpoints. Testing will be a key focus, with the development of meticulous test plans, test cases, and comprehensive bug reports to ensure the app's reliability. Additionally, the project will produce visually engaging app layouts, icons, and visual assets to enhance the user interface. To ensure users can effectively navigate and utilize the application, user guides and detailed documentation for the app's functionality will be part of the deliverables.`}/>
            </Grid>
        </Grid>
    )
}

export default Task1;