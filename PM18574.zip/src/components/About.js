
import * as React from 'react';
import qrcode from '../img/qrcode.png' 

import {Box, Button, ButtonGroup, Paper, IconButton, Container, Grid, Typography} from '@mui/material';

function About() {
    return (
        <Grid id='About' container spacing={2} marginY={2} alignItems='center'>
            <Grid item xs={12} lg={8}>
            <Typography variant='h4' gutterBottom>E-Commerce Mobile App Development</Typography>
            <Typography variant='body1' sx={{textAlign:'justify'}} mb={2} mr={3}>
In today's dynamic digital landscape, staying competitive in the e-commerce industry demands not only a compelling online presence but also a seamless user experience. Our endeavor is to bridge the gap between consumers and the products they desire by embarking on an exciting journey – the development of an E-Commerce Mobile App.

In this age of technological innovation, our goal is to create a user-friendly, efficient, and visually appealing mobile application that not only simplifies the shopping experience but also adds value to our customers' lives. This mobile app will serve as a direct gateway to a world of products and services, enabling customers to browse, select, and purchase with unparalleled ease.</Typography>
            <ButtonGroup  color='secondary' variant='contained' aria-label="outlined button group">
                <Button href='/18574_Project Management_Assessment 1.docx' download>Assessment One</Button>
                <Button href='/18574_Project Management_Assessment 2.docx' download>Assessment Two</Button>
                <Button href='/18574 Gantt Project.gan' download>Gantt Project</Button>
                <Button href='/PM18574.zip' download>
                    Download Source Code
                </Button>
            </ButtonGroup>
            </Grid>
            <Grid item xs={12} lg={4} textAlign='center' sx={{
          display: { xs: 'none', md: 'block'} }}>
            <img width='100%' style={{paddingTop:'10px'}} src={qrcode} alt="qrcode" />
            <Typography mb={2} variant='h6' color='secondary'>SCAN TO VIEW ON MOBILE</Typography>
            </Grid>
        </Grid>
    )
}

export default About;