
import * as React from 'react';
import qrcode from '../img/qrcode.png' 

import {Box, Button, Paper, IconButton, Container, Grid, Typography} from '@mui/material';

function About() {
    return (
        <Grid id='About' container spacing={2} marginY={2} alignItems='center'>
            <Grid item xs={12} lg={8}>
            <Typography variant='h4' gutterBottom>About Us</Typography>
            <Typography variant='body2' sx={{textAlign:'justify'}} mb={2}>At Shepherd Pups, we breed healthy and well-adjusted German Shepherd puppies suitable for families, show competitions, or working roles. Our focus is on the health and well-being of our dogs, providing them with proper nutrition, exercise, and healthcare. We carefully select the parents of each litter based on their temperament, health, and breed standards and prioritize socialization to build their confidence and prepare them for their new homes.
            <br/><br/>
We are dedicated to providing excellent customer service and support to our clients, educating potential buyers about the breed's temperament, needs, and training requirements, and offering ongoing support to ensure that their puppies thrive in their new homes. As a registered breeder with the Australian National Kennel Council and a member of various dog clubs and associations, we adhere to their Code of Ethics, ensuring that we provide the best possible care to our dogs and puppies. With our commitment to breeding healthy, well-adjusted puppies and providing exceptional customer service, Shepherd Pups is an excellent choice for those looking for a reputable breeder in Sydney.</Typography>
            <Button fullWidth variant='contained' href='/build.zip' download>
                Download Source Code
            </Button>
            </Grid>
            <Grid item xs={12} lg={4} textAlign='center' sx={{
          display: { xs: 'none', md: 'block' } }}>
            <Typography variant='h4'>View on Mobile</Typography>
            <img src={qrcode} alt="qrcode" />
            </Grid>
        </Grid>
    )
}

export default About;